import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class FormServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter out= resp.getWriter();
        out.print("<html><head><title></title></head><body>");
        out.print("<form method='post' action='support'>");
        out.print("<h1>Please fill this form:</h1>");
        out.print("Name:<input type='text' name='reqname'/><br/><br/>");
        out.print("Email:<input type='text' name='email' placeholder='email@gmail.com'/><br/><br/>");
        out.print("Problem:<input type='text' name='problem'/><br/><br/>");
        out.print("Problem Description:<textarea cols=4 rows=3 type='text' name='problemdesc'></textarea>");
        out.print("<br/><br/>");
        out.print("<input type='submit' value='help'/>");
        out.print("</form>");
        out.print("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContext sc= this.getServletContext();
        PrintWriter out= resp.getWriter();
        out.print("Thank you! "+ req.getParameter("reqname") +" for contacting us. You should receive reply from us with in 24 hrs in your email: "+req.getParameter("email")+". Let us know in our support email: "+sc.getInitParameter("support-email")+" ,if you don't receive reply within 24 hrs. Please be sure to attach your reference "+ ticketgenerate()+" in your email. ");

    }
    int i=0;
    public String ticketgenerate(){
        String code="";
        boolean c=true;
           code="support_ticket_"+i;
           i++;
        return code;
    }
}
